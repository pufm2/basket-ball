package puf.m2.basket.view;

public enum FormState {
	INITIAL, NEW, FIND
}
