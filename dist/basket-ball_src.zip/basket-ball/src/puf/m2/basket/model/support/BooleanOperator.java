package puf.m2.basket.model.support;

public enum BooleanOperator {
	and,
	or;
}
