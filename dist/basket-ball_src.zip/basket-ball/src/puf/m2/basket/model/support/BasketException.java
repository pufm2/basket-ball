package puf.m2.basket.model.support;

public class BasketException extends Exception {

    private static final long serialVersionUID = -4388086838287240275L;
    
    public BasketException() {
        
    }
    
    public BasketException(Throwable throwable) {
        super(throwable);
    }

}
