package puf.m2.basket.exception;

public class DbException extends Exception {

    private static final long serialVersionUID = 5650572940193061580L;
    
    public DbException(Throwable cause) {
        super(cause);
    }
    
}
