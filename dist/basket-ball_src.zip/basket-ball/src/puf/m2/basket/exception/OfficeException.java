package puf.m2.basket.exception;


public class OfficeException extends BasketException{

    private static final long serialVersionUID = 71594181220815027L;

    public OfficeException(Throwable cause) {
        super(cause);
    }
}
