package puf.m2.basket.db;

import static org.junit.Assert.*;

import org.junit.Test;

public class JDBCUtilTest {

    @Test
    public void test() {

    }

}
